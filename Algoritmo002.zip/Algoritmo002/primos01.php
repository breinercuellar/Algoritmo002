<?php
class Primo {
    public function esPrimo($numero) {
        if ($numero <= 1) {
            return false;
        }
        if ($numero == 2) {
            return true;
        }
        if ($numero % 2 == 0) {
            return false;
        }
        $divisor = 5;
        while ($divisor * $divisor <= $numero) {
            if ($numero % $divisor == 0) {
                return false;
            }
            $divisor = $divisor + 2;
        }
        return true;
    }
}

$numero = 5;
$primo = new Primo();
if ($primo->esPrimo($numero)) {
    echo $numero . " es primo";
} else {
    echo $numero . " no es primo";
}
?> 